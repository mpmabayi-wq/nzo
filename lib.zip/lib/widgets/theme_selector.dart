import 'package:flutter/material.dart';

import '../core/state/app_state.dart';
import '../core/theme/app_themes.dart';

class ThemeSelector extends StatelessWidget {
  const ThemeSelector({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);

    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Column(
      children: [
        for (var i = 0; i < AppThemes.options.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),

            child: Material(
              color: Colors.transparent,

              child: InkWell(
                borderRadius: BorderRadius.circular(16),

                onTap: () {
                  state.setTheme(i);
                },

                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),

                  curve: Curves.easeInOut,

                  padding: const EdgeInsets.all(14),

                  decoration: BoxDecoration(
                    color: state.themeIndex == i
                        ? scheme.primaryContainer.withValues(alpha: 0.35)
                        : scheme.surfaceContainerLow,

                    borderRadius: BorderRadius.circular(16),

                    border: Border.all(
                      color: state.themeIndex == i
                          ? scheme.primary
                          : scheme.outlineVariant,

                      width: state.themeIndex == i ? 2 : 1,
                    ),
                  ),

                  child: Row(
                    children: [

                      // Couleur représentative du thème

                      CircleAvatar(
                        radius: 21,

                        backgroundColor: AppThemes.options[i].seed,

                        child: state.themeIndex == i
                            ? const Icon(
                          Icons.check_rounded,
                          color: Colors.white,
                          size: 23,
                        )
                            : null,
                      ),

                      const SizedBox(width: 14),

                      // Nom et description

                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,

                          children: [
                            Text(
                              AppThemes.options[i].name,

                              style: theme.textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w700,
                                color: scheme.onSurface,
                              ),
                            ),

                            const SizedBox(height: 3),

                            Text(
                              AppThemes.options[i].description,

                              style: theme.textTheme.bodyMedium?.copyWith(
                                color: scheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(width: 8),

                      // Indicateur de sélection

                      if (state.themeIndex == i)
                        Icon(
                          Icons.check_circle_rounded,
                          color: scheme.primary,
                          size: 26,
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}