import 'package:flutter/material.dart';
import '../../core/state/app_state.dart';
import '../../core/utils/metrics.dart';
import '../../data/property.dart';
import '../../widgets/common.dart';
import '../../widgets/pill.dart';
import '../../widgets/property_card.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key, required this.request});

  final ValueNotifier<SearchRequest?> request;

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _controller = TextEditingController();
  String _offer = 'Tous';
  String _type = 'Tous';
  String _commune = 'Toutes';

  @override
  void initState() {
    super.initState();
    widget.request.addListener(_onRequest);
  }

  @override
  void dispose() {
    widget.request.removeListener(_onRequest);
    _controller.dispose();
    super.dispose();
  }

  void _onRequest() {
    final r = widget.request.value;
    if (r == null) return;
    setState(() {
      _offer = r.offer ?? 'Tous';
      _type = r.type ?? 'Tous';
      _commune = 'Toutes';
      _controller.clear();
    });
    widget.request.value = null;
  }

  void _reset() {
    setState(() {
      _offer = 'Tous';
      _type = 'Tous';
      _commune = 'Toutes';
      _controller.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final m = context.m;
    final state = AppScope.of(context);
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;

    final query = _controller.text.trim().toLowerCase();
    final results = state.properties.where((p) {
      if (_offer != 'Tous' && p.offer != _offer) return false;
      if (_type != 'Tous' && p.type != _type) return false;
      if (_commune != 'Toutes' && p.commune != _commune) return false;
      if (query.isNotEmpty) {
        final hay = '${p.title} ${p.quartier} ${p.commune} ${p.type}'.toLowerCase();
        if (!hay.contains(query)) return false;
      }
      return true;
    }).toList();

    final filtering = _offer != 'Tous' || _type != 'Tous' || _commune != 'Toutes' || query.isNotEmpty;

    return ListView(
      padding: EdgeInsets.only(bottom: m.s(24)),
      children: [
        const PageHeader(title: 'Rechercher', subtitle: 'Trouvez le bien qui vous convient'),
        Padding(
          padding: m.pageH,
          child: TextField(
            controller: _controller,
            onChanged: (_) => setState(() {}),
            textInputAction: TextInputAction.search,
            style: text.bodyLarge,
            decoration: InputDecoration(
              hintText: 'Quartier, type de bien…',
              prefixIcon: Icon(Icons.search_rounded, size: m.icon(24)),
              suffixIcon: _controller.text.isEmpty
                  ? null
                  : IconButton(
                      tooltip: 'Effacer',
                      icon: Icon(Icons.close_rounded, size: m.icon(22)),
                      onPressed: () => setState(_controller.clear),
                    ),
            ),
          ),
        ),
        SizedBox(height: m.s(18)),
        _Label('Je cherche'),
        HScroll(children: [
          for (final o in ['Tous', ...kOffers])
            Pill(label: o, selected: _offer == o, onTap: () => setState(() => _offer = o)),
        ]),
        SizedBox(height: m.s(16)),
        _Label('Type de bien'),
        HScroll(children: [
          Pill(label: 'Tous', selected: _type == 'Tous', onTap: () => setState(() => _type = 'Tous')),
          for (final t in kTypes)
            Pill(
              label: t,
              icon: iconForType(t),
              selected: _type == t,
              onTap: () => setState(() => _type = t),
            ),
        ]),
        SizedBox(height: m.s(16)),
        _Label('Commune'),
        HScroll(children: [
          for (final c in ['Toutes', ...kCommunes])
            Pill(label: c, selected: _commune == c, onTap: () => setState(() => _commune = c)),
        ]),
        SizedBox(height: m.s(22)),
        Padding(
          padding: m.pageH,
          child: Row(
            children: [
              Expanded(
                child: Text(
                  results.length <= 1 ? '${results.length} résultat' : '${results.length} résultats',
                  style: text.titleMedium,
                ),
              ),
              if (filtering)
                TextButton.icon(
                  onPressed: _reset,
                  icon: Icon(Icons.restart_alt_rounded, size: m.icon(20)),
                  label: const Text('Réinitialiser'),
                ),
            ],
          ),
        ),
        SizedBox(height: m.s(8)),
        if (results.isEmpty)
          EmptyState(
            icon: Icons.search_off_rounded,
            title: 'Aucun bien trouvé',
            message: 'Essayez de modifier vos filtres ou de chercher un autre quartier.',
            actionLabel: 'Réinitialiser les filtres',
            onAction: _reset,
          )
        else
          Padding(
            padding: m.pageH,
            child: Column(children: [for (final p in results) PropertyCard(property: p)]),
          ),
      ],
    );
  }
}

class _Label extends StatelessWidget {
  const _Label(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    final m = context.m;
    return Padding(
      padding: EdgeInsets.fromLTRB(m.s(20), 0, m.s(20), m.s(10)),
      child: Text(
        text,
        style: Theme.of(context)
            .textTheme
            .labelLarge
            ?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
      ),
    );
  }
}
