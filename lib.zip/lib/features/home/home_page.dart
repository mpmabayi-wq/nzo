import 'package:flutter/material.dart';
import '../../core/state/app_state.dart';
import '../../core/theme/app_themes.dart';
import '../../core/utils/metrics.dart';
import '../../data/property.dart';
import '../../widgets/common.dart';
import '../../widgets/nzo_logo.dart';
import '../../widgets/property_card.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.onSearch});

  final void Function(SearchRequest request) onSearch;

  String get _greeting => DateTime.now().hour < 18 ? 'Bonjour' : 'Bonsoir';

  @override
  Widget build(BuildContext context) {
    final m = context.m;
    final state = AppScope.of(context);
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;

    final featured = state.properties.take(5).toList();

    return ListView(
      padding: EdgeInsets.only(bottom: m.s(24)),
      children: [
        // En-tête
        Padding(
          padding: EdgeInsets.fromLTRB(m.s(20), m.s(16), m.s(20), m.s(18)),
          child: Row(
            children: [
              NzoLogo(height: m.s(46)),
              SizedBox(width: m.s(12)),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('$_greeting 👋',
                        style: text.bodyMedium?.copyWith(color: scheme.onSurfaceVariant)),
                    Text('Que cherchez-vous ?', style: text.titleLarge),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: m.s(12), vertical: m.s(8)),
                decoration: BoxDecoration(
                  color: scheme.primaryContainer,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.location_on_rounded, size: m.icon(16), color: scheme.primary),
                    SizedBox(width: m.s(4)),
                    Text('Matadi',
                        style: text.labelMedium?.copyWith(color: scheme.onPrimaryContainer)),
                  ],
                ),
              ),
            ],
          ),
        ),

        // Barre de recherche
        Padding(
          padding: m.pageH,
          child: SoftCard(
            radius: 20,
            onTap: () => onSearch(const SearchRequest()),
            padding: EdgeInsets.symmetric(horizontal: m.s(16), vertical: m.s(8)),
            child: Row(
              children: [
                Icon(Icons.search_rounded, size: m.icon(26), color: scheme.onSurfaceVariant),
                SizedBox(width: m.s(12)),
                Expanded(
                  child: Text(
                    'Quartier, type de bien…',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: text.bodyLarge?.copyWith(color: scheme.onSurfaceVariant),
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(m.s(10)),
                  decoration: BoxDecoration(color: scheme.primary, shape: BoxShape.circle),
                  child: Icon(Icons.tune_rounded, size: m.icon(20), color: scheme.onPrimary),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: m.s(18)),

        // Louer / Acheter
        Padding(
          padding: m.pageH,
          child: Row(
            children: [
              Expanded(
                child: _ActionTile(
                  title: 'Louer',
                  subtitle: 'Maisons, studios…',
                  icon: Icons.key_rounded,
                  colors: const [AppColors.brandLight, AppColors.brandDeep],
                  foreground: Colors.white,
                  onTap: () => onSearch(const SearchRequest(offer: 'Location')),
                ),
              ),
              SizedBox(width: m.s(12)),
              Expanded(
                child: _ActionTile(
                  title: 'Acheter',
                  subtitle: 'Villas, parcelles…',
                  icon: Icons.sell_rounded,
                  colors: const [Color(0xFFF7C566), AppColors.goldDeep],
                  foreground: const Color(0xFF3A2600),
                  onTap: () => onSearch(const SearchRequest(offer: 'Vente')),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: m.s(26)),

        // Catégories
        Padding(padding: m.pageH, child: const SectionHeader(title: 'Catégories')),
        SizedBox(height: m.s(6)),
        HScroll(
          gap: 14,
          children: [
            _Category('Maisons', Icons.home_rounded, () => onSearch(const SearchRequest(type: 'Maison'))),
            _Category('Apparts', Icons.apartment_rounded, () => onSearch(const SearchRequest(type: 'Appartement'))),
            _Category('Studios', Icons.bed_rounded, () => onSearch(const SearchRequest(type: 'Chambre / Studio'))),
            _Category('Parcelles', Icons.landscape_rounded, () => onSearch(const SearchRequest(type: 'Parcelle'))),
            _Category('Commerces', Icons.storefront_rounded, () => onSearch(const SearchRequest(type: 'Local commercial'))),
          ],
        ),
        SizedBox(height: m.s(24)),

        // À la une
        Padding(
          padding: m.pageH,
          child: SectionHeader(
            title: 'À la une',
            actionLabel: 'Voir tout',
            onAction: () => onSearch(const SearchRequest()),
          ),
        ),
        SizedBox(height: m.s(6)),
        SizedBox(
          height: m.s(132) + m.fit(128),
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.fromLTRB(m.s(20), m.s(4), m.s(20), m.s(12)),
            itemCount: featured.length,
            separatorBuilder: (_, __) => SizedBox(width: m.s(14)),
            itemBuilder: (_, i) => FeaturedCard(property: featured[i]),
          ),
        ),
        SizedBox(height: m.s(14)),

        // Récentes
        Padding(padding: m.pageH, child: const SectionHeader(title: 'Annonces récentes')),
        SizedBox(height: m.s(10)),
        Padding(
          padding: m.pageH,
          child: Column(
            children: [for (final p in state.properties) PropertyCard(property: p)],
          ),
        ),
      ],
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.colors,
    required this.foreground,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;
  final Color foreground;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final m = context.m;
    final text = Theme.of(context).textTheme;
    final r = BorderRadius.circular(m.s(22));
    return Material(
      borderRadius: r,
      color: Colors.transparent,
      child: Ink(
        decoration: BoxDecoration(
          borderRadius: r,
          gradient: LinearGradient(
            colors: colors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: colors.last.withValues(alpha: 0.28),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: InkWell(
          borderRadius: r,
          onTap: onTap,
          child: Padding(
            padding: EdgeInsets.all(m.s(16)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.all(m.s(10)),
                  decoration: BoxDecoration(
                    color: foreground.withValues(alpha: 0.16),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, size: m.icon(24), color: foreground),
                ),
                SizedBox(height: m.s(14)),
                Text(title, style: text.titleLarge?.copyWith(color: foreground)),
                SizedBox(height: m.s(2)),
                Text(subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: text.bodySmall?.copyWith(color: foreground.withValues(alpha: 0.85))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Category extends StatelessWidget {
  const _Category(this.label, this.icon, this.onTap);

  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final m = context.m;
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(m.s(16)),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerLow,
              borderRadius: BorderRadius.circular(m.s(20)),
              border: Border.all(color: scheme.outlineVariant),
            ),
            child: Icon(icon, size: m.icon(28), color: scheme.primary),
          ),
          SizedBox(height: m.s(8)),
          Text(label, style: text.labelMedium),
        ],
      ),
    );
  }
}
