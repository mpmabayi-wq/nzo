import 'package:flutter/material.dart';
import '../../core/state/app_state.dart';
import '../../core/utils/metrics.dart';
import '../favorites/favorites_page.dart';
import '../profile/profile_page.dart';
import '../publish/publish_page.dart';
import '../search/search_page.dart';
import 'home_page.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;
  final ValueNotifier<SearchRequest?> _searchRequest = ValueNotifier<SearchRequest?>(null);

  void _goTo(int i) => setState(() => _index = i);

  void _openSearch(SearchRequest request) {
    _searchRequest.value = request;
    _goTo(1);
  }

  @override
  void dispose() {
    _searchRequest.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final m = context.m;

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: IndexedStack(
              index: _index,
              children: [
                HomePage(onSearch: _openSearch),
                SearchPage(request: _searchRequest),
                PublishPage(onPublished: () => _goTo(0)),
                FavoritesPage(onExplore: () => _goTo(0)),
                const ProfilePage(),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: _goTo,
        destinations: [
          NavigationDestination(
            icon: Icon(Icons.home_outlined, size: m.icon(24)),
            selectedIcon: Icon(Icons.home_rounded, size: m.icon(24)),
            label: 'Accueil',
          ),
          NavigationDestination(
            icon: Icon(Icons.search_rounded, size: m.icon(24)),
            selectedIcon: Icon(Icons.search_rounded, size: m.icon(24)),
            label: 'Chercher',
          ),
          NavigationDestination(
            icon: Icon(Icons.add_circle_outline_rounded, size: m.icon(24)),
            selectedIcon: Icon(Icons.add_circle_rounded, size: m.icon(24)),
            label: 'Publier',
          ),
          NavigationDestination(
            icon: Icon(Icons.favorite_border_rounded, size: m.icon(24)),
            selectedIcon: Icon(Icons.favorite_rounded, size: m.icon(24)),
            label: 'Favoris',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded, size: m.icon(24)),
            selectedIcon: Icon(Icons.person_rounded, size: m.icon(24)),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}
