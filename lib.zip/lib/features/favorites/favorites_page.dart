import 'package:flutter/material.dart';
import '../../core/state/app_state.dart';
import '../../core/utils/metrics.dart';
import '../../widgets/common.dart';
import '../../widgets/property_card.dart';

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key, required this.onExplore});

  final VoidCallback onExplore;

  @override
  Widget build(BuildContext context) {
    final m = context.m;
    final state = AppScope.of(context);
    final favs = state.properties.where((p) => state.isFavorite(p.id)).toList();

    return ListView(
      padding: EdgeInsets.only(bottom: m.s(24)),
      children: [
        PageHeader(
          title: 'Mes favoris',
          subtitle: favs.isEmpty
              ? 'Gardez vos annonces préférées ici'
              : (favs.length == 1 ? '1 annonce enregistrée' : '${favs.length} annonces enregistrées'),
        ),
        if (favs.isEmpty)
          EmptyState(
            icon: Icons.favorite_border_rounded,
            title: 'Aucun favori pour le moment',
            message: 'Appuyez sur le cœur d\'une annonce pour la retrouver facilement ici.',
            actionLabel: 'Découvrir les annonces',
            onAction: onExplore,
          )
        else
          Padding(
            padding: m.pageH,
            child: Column(children: [for (final p in favs) PropertyCard(property: p)]),
          ),
      ],
    );
  }
}
