import 'package:flutter/material.dart';

// =====================================================
// COULEURS DE L'APPLICATION
// =====================================================

class AppColors {
  static const brand = Color(0xFF0B5FA5);
  static const brandLight = Color(0xFF1B7FD1);
  static const brandDeep = Color(0xFF083F73);

  static const gold = Color(0xFFF2B84B);
  static const goldDeep = Color(0xFFE59A1F);

  static const whatsapp = Color(0xFF1FAF5A);
}

// =====================================================
// MODÈLE DES OPTIONS DE THÈME
// =====================================================

class ThemeOption {
  final String name;
  final String description;
  final Color seed;

  const ThemeOption({
    required this.name,
    required this.description,
    required this.seed,
  });
}

// =====================================================
// GESTION DES THÈMES
// =====================================================

class AppThemes {

  // ---------------------------------------------------
  // PALETTES DISPONIBLES
  // ---------------------------------------------------

  static const List<ThemeOption> options = [
    ThemeOption(
      name: 'Bleu classique',
      description: 'Le style original et professionnel.',
      seed: Color(0xFF0B5FA5),
    ),
    ThemeOption(
      name: 'Bleu moderne',
      description: 'Une apparence lumineuse et contemporaine.',
      seed: Color(0xFF1B7FD1),
    ),
    ThemeOption(
      name: 'Vert nature',
      description: 'Une ambiance naturelle et apaisante.',
      seed: Color(0xFF16865B),
    ),
    ThemeOption(
      name: 'Violet élégant',
      description: 'Un style moderne et raffiné.',
      seed: Color(0xFF7952B3),
    ),
    ThemeOption(
      name: 'Orange dynamique',
      description: 'Une ambiance chaleureuse et énergique.',
      seed: Color(0xFFE58A23),
    ),
  ];

  // ---------------------------------------------------
  // THÈMES CLAIR ET SOMBRE
  // ---------------------------------------------------

  static ThemeData light({int themeIndex = 0}) {
    return _build(
      Brightness.light,
      themeIndex,
    );
  }

  static ThemeData dark({int themeIndex = 0}) {
    return _build(
      Brightness.dark,
      themeIndex,
    );
  }

  // ---------------------------------------------------
  // CONSTRUCTION DU THÈME
  // ---------------------------------------------------

  static ThemeData _build(
      Brightness brightness,
      int themeIndex,
      ) {
    final dark = brightness == Brightness.dark;

    final safeIndex = themeIndex.clamp(0, options.length - 1);

    final seedColor = options[safeIndex].seed;

    final scheme = ColorScheme.fromSeed(
      seedColor: seedColor,
      brightness: brightness,
    ).copyWith(
      primary: dark
          ? Color.lerp(seedColor, Colors.white, 0.30)!
          : seedColor,

      onPrimary: dark
          ? const Color(0xFF10243A)
          : Colors.white,

      primaryContainer: dark
          ? Color.lerp(seedColor, Colors.black, 0.65)!
          : Color.lerp(seedColor, Colors.white, 0.85)!,

      onPrimaryContainer: dark
          ? const Color(0xFFE8F1FC)
          : const Color(0xFF10243A),

      secondary: AppColors.gold,

      onSecondary: const Color(0xFF3A2600),

      secondaryContainer: dark
          ? const Color(0xFF4A3510)
          : const Color(0xFFFFEFD0),

      onSecondaryContainer: dark
          ? const Color(0xFFFFE2A8)
          : const Color(0xFF3A2600),

      surface: dark
          ? const Color(0xFF0B1220)
          : const Color(0xFFF5F8FC),

      onSurface: dark
          ? const Color(0xFFE8EEF6)
          : const Color(0xFF0C1B2C),

      onSurfaceVariant: dark
          ? const Color(0xFF9DB0C6)
          : const Color(0xFF526478),

      surfaceContainerLowest: dark
          ? const Color(0xFF080D18)
          : Colors.white,

      surfaceContainerLow: dark
          ? const Color(0xFF111A2B)
          : Colors.white,

      surfaceContainer: dark
          ? const Color(0xFF151F32)
          : const Color(0xFFEEF3F9),

      surfaceContainerHigh: dark
          ? const Color(0xFF1B2740)
          : const Color(0xFFE6EDF6),

      surfaceContainerHighest: dark
          ? const Color(0xFF223050)
          : const Color(0xFFDDE6F1),

      outline: dark
          ? const Color(0xFF5F738C)
          : const Color(0xFF8A9BB0),

      outlineVariant: dark
          ? const Color(0xFF26344D)
          : const Color(0xFFD9E2ED),

      error: dark
          ? const Color(0xFFFF8A80)
          : const Color(0xFFD93025),
    );

    // -------------------------------------------------
    // TYPOGRAPHIE
    // -------------------------------------------------

    final textTheme = const TextTheme(
      headlineLarge: TextStyle(
        fontSize: 32,
        fontWeight: FontWeight.w800,
        height: 1.15,
        letterSpacing: -0.6,
      ),

      headlineMedium: TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.w800,
        height: 1.18,
        letterSpacing: -0.5,
      ),

      headlineSmall: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w800,
        height: 1.2,
        letterSpacing: -0.3,
      ),

      titleLarge: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        height: 1.25,
        letterSpacing: -0.2,
      ),

      titleMedium: TextStyle(
        fontSize: 17,
        fontWeight: FontWeight.w700,
        height: 1.3,
      ),

      titleSmall: TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.w600,
        height: 1.3,
      ),

      bodyLarge: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        height: 1.45,
      ),

      bodyMedium: TextStyle(
        fontSize: 14.5,
        fontWeight: FontWeight.w400,
        height: 1.45,
      ),

      bodySmall: TextStyle(
        fontSize: 12.5,
        fontWeight: FontWeight.w400,
        height: 1.4,
      ),

      labelLarge: TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.w600,
      ),

      labelMedium: TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.w600,
      ),

      labelSmall: TextStyle(
        fontSize: 11.5,
        fontWeight: FontWeight.w600,
      ),
    );

    // -------------------------------------------------
    // FORMES ET BORDURES
    // -------------------------------------------------

    final radius16 = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(16),
    );

    OutlineInputBorder border(
        Color color, [
          double width = 1,
        ]) {
      return OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(
          color: color,
          width: width,
        ),
      );
    }

    // -------------------------------------------------
    // THÈME DE BASE
    // -------------------------------------------------

    final base = ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      textTheme: textTheme,
      splashFactory: InkRipple.splashFactory,
    );

    // -------------------------------------------------
    // CONFIGURATION COMPLÈTE
    // -------------------------------------------------

    return base.copyWith(

      textTheme: base.textTheme.apply(
        bodyColor: scheme.onSurface,
        displayColor: scheme.onSurface,
      ),

      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: scheme.onSurface,
      ),

      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(54),
          shape: radius16,
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size.fromHeight(54),
          shape: radius16,
          side: BorderSide(
            color: scheme.outlineVariant,
            width: 1.4,
          ),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          textStyle: const TextStyle(
            fontSize: 14.5,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: scheme.surfaceContainerLow,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 17,
        ),
        hintStyle: TextStyle(
          color: scheme.onSurfaceVariant,
        ),
        border: border(scheme.outlineVariant),
        enabledBorder: border(scheme.outlineVariant),
        focusedBorder: border(scheme.primary, 1.8),
        errorBorder: border(scheme.error),
        focusedErrorBorder: border(scheme.error, 1.8),
      ),

      navigationBarTheme: NavigationBarThemeData(
        height: 72,
        elevation: 0,
        backgroundColor: scheme.surfaceContainerLow,
        surfaceTintColor: Colors.transparent,
        indicatorColor: scheme.primaryContainer,

        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);

          return TextStyle(
            fontSize: 12,
            fontWeight: selected
                ? FontWeight.w700
                : FontWeight.w500,
            color: selected
                ? scheme.primary
                : scheme.onSurfaceVariant,
          );
        }),
      ),

      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: scheme.surfaceContainerLow,
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(28),
          ),
        ),
      ),

      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),

      dividerTheme: DividerThemeData(
        color: scheme.outlineVariant,
        space: 1,
        thickness: 1,
      ),
    );
  }
}